struct Azienda
{
    char NomeAzienda[64];
    int Dipendenti;
    int Dipartimenti;
    int Sedi;
    
    struct Azienda* successivo;

};

