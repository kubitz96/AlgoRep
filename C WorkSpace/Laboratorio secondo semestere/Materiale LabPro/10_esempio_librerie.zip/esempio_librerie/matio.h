#ifndef MATIO_H
#define MATIO_H

#include "matcalc.h"
void stampa_vett(int vett[], int n);
void stampa_mat(int mat[][MAX_COLS], int n_r, int n_c);


#endif
