#ifndef QUEUE_DATATYPE
#define QUEUE_DATATYPE
struct Coda
{
    int* deposito;
    int size;
};
#endif
